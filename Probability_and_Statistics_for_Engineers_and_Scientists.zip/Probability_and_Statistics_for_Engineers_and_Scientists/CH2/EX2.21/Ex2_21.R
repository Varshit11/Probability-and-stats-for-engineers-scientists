# Chapter 2
# Example 2.21 page no. 50 from the pdf..
# Partition Problem..


# number of ways, 7 students are assigned 1 triple and 2 double rooms..

# answer..
cat("The number of ways in which this partition can be done are",(factorial(7)/(factorial(3)*factorial(2)*factorial(2))))





