
# CHapter 9
# Example 9.16 page no. 299 from the pdf..
# Evaluate sample size for estimating a Proportion for Single Sample..

# to find a sample size if we want atleast 95% confidence interval


e <- 0.02     # error not exceeding this value

cat("The sample size if we want atleast 95% confidence interval that our estimate of p is within 0.02 of the true value is",round(qnorm(0.025)*qnorm(0.025)/(4*e*e)))


# In Example 9.17 all we have to do is put the values in the formula mentioned in the pdf and get the answer,I have solved some questions based on this but I am not going to solve, that's understood from the questions itself and will be a very straight forward code..

