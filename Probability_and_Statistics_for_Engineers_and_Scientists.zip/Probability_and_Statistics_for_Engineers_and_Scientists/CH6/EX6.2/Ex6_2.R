
# Chapter 6
# Example 6.2 page no.178 from the pdf..
# NOrmal Distribution Problem..

# given standard normal distribution..


cat("The area under the curve to the right of 1.84 is",pnorm(1.84,lower.tail = F))


cat("The area under the curve that lies between z=-1.97 to z=0.86 is",pnorm(0.86)-pnorm(-1.97))


# the answer in the textbook is approx.to 4 decimal places..

