
# Chapter 8
# Example 8.8 page no. 249 from the pdf..
# The t-distribution Problem..

# to find the t value with left tail area 0.025 and degrees of freedom =14

cat("The t value with degrees of freedom 14 and leaves an area of 0.025 to the left is",qt(0.025,df= 14))

# Note- In example 8.9 the degrees of freedom is not mentioned so I am not solving example 8.9, I think the solution is wrong..
