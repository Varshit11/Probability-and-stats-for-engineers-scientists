
# Chapter 15
# example 15.4 page no. 619
# Standard Errors of the least Sqaures Regression Coefficients

# given data and anova table, to find the standard errors of the least squares regression coefficients..

# Note 15.3 - Theoretical with nothing to compute..

# standard errors of all coefficients for the 2^k factorial are equal so..
# from anova table given s^2 = 2.46

cat("The standard error of the least squares regression coefficients are",sqrt(2.46/(2^4*2)))




