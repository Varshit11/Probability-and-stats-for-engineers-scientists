
# Chapter 2
# Example 2.19a page no.48 from the pdf..
# Permuation Problem 
# number of ways to select president and treasurer from 50 students without restriction


cat("The number of choices of officers without restriction are",factorial(50)/factorial(48))


# It is simply permutation of 50 with 2 



