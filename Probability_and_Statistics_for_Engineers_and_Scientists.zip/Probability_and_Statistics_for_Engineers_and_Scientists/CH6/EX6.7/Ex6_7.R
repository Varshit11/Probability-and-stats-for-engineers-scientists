
# CHapter 6
# Example 6.7 page no. 182 from the pdf..
# Applications of Normal Distribution..

# given - average battery life- 3 years
# standars deviation - 0.5
# to find P(X<2.3)

cat("The probability that a given battery will last less than 2.3 years is",pnorm(2.3,mean = 3,sd= 0.5))








