# Chapter 1
# Example 1.4 page no. 15 from the pdf..
# To find the mean, sample variance, and standard deviation.


a <- c(7.00, 7.07,7.10,6.97,7.00,7.03,7.01,7.01,6.98,7.08)

cat("The sample mean is ",mean(a))

cat("The sample variance is ",var(a))

cat("The sample standard deviation is ", sd(a))