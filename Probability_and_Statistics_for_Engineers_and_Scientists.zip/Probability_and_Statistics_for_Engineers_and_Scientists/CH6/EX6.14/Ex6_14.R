
# Chapter 6
# example 6.14 page no.185 from the pdf..
# Applications of Normal Distribution..

# given - mean 74, sd - 7
# to find the sixth decile..

cat("The sixth decile is",qnorm(0.6,mean = 74,sd = 7))


# the answer varies slightly due to approximation used in the T.B
