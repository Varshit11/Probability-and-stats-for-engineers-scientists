
# Chapter 2
# Example 2.2 page no. 36 from the pdf..
# To Find the Sample Space..

a <- c(rep("H",2),rep("T",6))

b <- c("H","T",seq(1,6))

paste(a,b)  #concatening both vectores to make a sample space


