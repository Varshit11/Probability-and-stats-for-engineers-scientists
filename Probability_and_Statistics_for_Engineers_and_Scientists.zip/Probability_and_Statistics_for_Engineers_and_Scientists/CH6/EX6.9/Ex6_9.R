
# Chapter 6
# Example 6.9 page no. 182 from the pdf..
# Applications of Normal Distribution..


# given normal, mean= 3,sd= 0.005

# specification on diameter of ball bearing 3+0.01 and 3-.01

cat("On average",2*pnorm(2.99,3,0.005)*100,"% of ball bearings will be scrapped")



