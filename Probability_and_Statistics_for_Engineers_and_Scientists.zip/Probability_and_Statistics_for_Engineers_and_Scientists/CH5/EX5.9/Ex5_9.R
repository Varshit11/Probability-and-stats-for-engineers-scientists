
# Chapter 5
# Example 5.9 Page no. 154 from the pdf..
# Hypergeometric Distribution Problem..

# to find prob. that exactly 1 defective if there are 3 in the entire lot of 40 and 5 are selected randomly

# this is the problem of hypergeometric distribution..

cat("The probability that exactly 1 is found defective from 5 randomly selected components is",dhyper(1,3,37,5))




