
# Chapter 17
# Example 17.1 page no. 694 from the pdf..
# Expected Number of samples required..

# given n = 4 ,r = 1
# By graph we can see beta = 0.84

beta <- 0.84

cat("The mean of samples requires to detect the shift is",1/(1-beta))


