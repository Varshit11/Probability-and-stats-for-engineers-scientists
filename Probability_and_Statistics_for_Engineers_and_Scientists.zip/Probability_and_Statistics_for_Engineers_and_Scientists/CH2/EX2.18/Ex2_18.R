# Chapter 2
# Example 2.18 page no. 48, from the pdf..
# Permutation Problem..


# Final answer..
cat("The total number of sample points is",factorial(25)/factorial(22))



