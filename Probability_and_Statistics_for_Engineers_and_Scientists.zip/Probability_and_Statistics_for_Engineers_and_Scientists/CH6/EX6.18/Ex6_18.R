
# Chapter 6
# Example 6.18 page no. 178.
# Gamma Distribution Problem..

# given - beta- 1/5, alpha- 2

# to find the probability up to a minute will elapse by the time 2 calls have come in to the switchboard..

cat("The probability that up to a minute will elapse by the time 2 calls have come in to the switchboard is",pgamma(1,shape = 2,scale = 1/5))


# the answer in T.B is approx. to 0.96

