
# Chapter 6
# example 6.23 page number - 203 from pdf..
# Lognormal Distribution Problem..

# given a lognormal distribution with mu = 5.149 and sigma = 0.737
# to find the 5th percentile of the life of electronic control...


cat("The 5th percentile of such an distribution is",qlnorm(0.05,meanlog = 5.149, sdlog = 0.737))
