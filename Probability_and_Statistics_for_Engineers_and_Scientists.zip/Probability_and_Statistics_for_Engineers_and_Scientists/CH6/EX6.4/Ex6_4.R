
# Chapter 6
# Example 6.4 page no. 179 from the pdf..
# Find area under the Normal Distribution..

# given popukation mean= 50 ,sd= 10

cat("The probability that random variable X assumes a value between 45 and 62 is",pnorm(62,50,10)-pnorm(45,50,10))


