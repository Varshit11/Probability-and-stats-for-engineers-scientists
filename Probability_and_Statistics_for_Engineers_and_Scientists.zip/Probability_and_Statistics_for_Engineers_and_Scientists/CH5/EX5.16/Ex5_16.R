
# Chapter 5
# example 5.16, page no. 160 from the pdf..
# Geometic Distribution Problem..

# p = 0.05 of a connection during busy time..
# to find the prob. that 5 attempts are necessary for a successful call.

cat("The probability that 5 attempts are necessary for a successful call is",dgeom(4,0.05))





