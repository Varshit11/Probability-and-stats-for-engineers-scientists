
# Chapter 5
# Example 5.1 Page no. 145 from the pdf..
# Binomial Distribution Problem..

# to find the prob. that exactly 2 in 4 components test survive..

# given prob. of component surviving test 0.75

cat("The probability that exactly 2 will surivie in this test out of 4 is",dbinom(2,4,prob = 0.75))




