
# Chapter 5
# Example 5.17 page no. 162 from the pdf..
# Poisson Distribution Problem..

# given - avg no. of radioactive particle entering in 1msec is 4,

# to find- prob. of 6 particles entering in a given msec..

# using poisson distribution..

cat("The probability of 6 particles entering in a given millisecond is",dpois(6,4))

# the answer in the textbook is 0.1042 approx. to 4 decimal places..

