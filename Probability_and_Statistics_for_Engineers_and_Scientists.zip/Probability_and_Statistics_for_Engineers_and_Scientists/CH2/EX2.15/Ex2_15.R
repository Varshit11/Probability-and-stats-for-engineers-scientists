
# Chapter 2
# Example 2.15 page no. 46 from the pdf..
# Generalized Multiplication rule..

# answer..
cat("We can elect the chair and treasurer in ",22*21, "ways")  #Using multiplication rule


