
# Chapter 2
# Example 2.10 page no. 40 from the pdf..
# To find the Union of the given two sets

a <- c("a","b","c")

b <- c("b","c","d","e")

union(a,b)  #Displays the union of two sets..
