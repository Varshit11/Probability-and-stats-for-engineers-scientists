
# Chapter 2
# Example 2.22 page no. 50 from the pdf..
# Combination Problem..

# number of ways to select 3 arcade and 2 sports games from 10 arcade and 5 sports game
cat("The number of ways to select 3 arcade from 10 is",choose(10,3))

a <- choose(10,3)

cat("The number of ways of selecting 2 catridges from 5 is",choose(5,2))

b <- choose(5,2)

#using multiplication rule..
cat("The total number of ways of selecting 3 arcade and 2 sports games is",a*b)

# example 2.23 same as the above 2 questions 2.22 and 2.21..



