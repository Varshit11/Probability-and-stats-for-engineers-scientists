
# Chapter 8
# Example 8.2 page no. 229 from the pdf..
# Sample mean and Sample Variance..

# to find mean and variance..

set <- c(12,15,17,20)

cat("The mean and variance are",mean(set),"and",var(set),"respectively")

