
# Chapter 5
# example 5.15 page no. 160 from the pdf..
# Geometric Distribution Problem..

# find prob. that 5th item inspected is first defective found given 1 in every 100 items is defective..

# using geometric distribution..

cat("The probability that 5th item inspected is found to be defective is",dgeom(4,0.01))

# the answer in textbook is approximated, 4 digits to the decimal..
