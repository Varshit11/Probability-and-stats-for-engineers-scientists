# Chapter 2
# Example 2.8 page no. 40 from the Pdf..
# To find the Intersection of the two sets

a <- c("a","e","i","o","u")

b <- c("l","r","s","t")

intersect(a,b) #displays the common elements in a and b. If there is no element common then denotes a vector of 0 length


